// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("acceptance tests"); }
int main(){
  announce();
  return lionss_run_workload("acceptance-tests");
}
