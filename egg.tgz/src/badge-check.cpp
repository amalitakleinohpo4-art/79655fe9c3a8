// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("badge check\n", stdout);
  return lionss_run_workload("badge-check");
}
