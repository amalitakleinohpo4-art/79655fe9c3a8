// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("scaling bench"); }
int main(){
  announce();
  return lionss_run_workload("scaling-bench");
}
