// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("coverage diff"); }
int main(){
  announce();
  return lionss_run_workload("coverage-diff");
}
